	</div>
	<footer class="text-center">
		&#169; 2019 - Lương Trường Giang - (HUTECH)
	</footer>
</body>
</html>
